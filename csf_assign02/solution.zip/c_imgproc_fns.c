// C implementations of image processing functions

#include <stdlib.h>
#include <assert.h>
#include "imgproc.h"

uint32_t make_pixel(uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    return ((uint32_t)r << 24) |
           ((uint32_t)g << 16) |
           ((uint32_t)b << 8)  |
           (uint32_t)a;
}

uint8_t get_r(uint32_t px) {
    return (px >> 24) & 0xFF;
}

uint8_t get_g(uint32_t px) {
    return (px >> 16) & 0xFF;
}

uint8_t get_b(uint32_t px) {
    return (px >> 8) & 0xFF;
}

uint8_t get_a(uint32_t px) {
    return px & 0xFF;
}



//! Transform the color component values in each input pixel
//! by applying the bitwise complement operation. I.e., each bit
//! in the color component information should be inverted
//! (1 becomes 0, 0 becomes 1.) The alpha value of each pixel should
//! be left unchanged.
//!
//! @param input_img pointer to the input Image
//! @param output_img pointer to the output Image (in which the
//!                   transformed pixels should be stored)
void imgproc_complement( struct Image *input_img, struct Image *output_img ) {
  // TODO: implement
  int size = input_img->width * input_img->height;

  // manipulate the pixels for complement
  for (int i = 0; i < size; i++) {
    uint32_t pixel_data = input_img->data[i];

    uint32_t alpha_save = pixel_data & 0x000000FF; // only stores alpha bits
    uint32_t rgb_save = pixel_data & 0xFFFFFF00; // only stores the rbg bits
    uint32_t rgb_flip = (~rgb_save) & 0xFFFFFF00; // flip the rgb bits

    output_img->data[i] = alpha_save | rgb_flip; 
  }
}

//! Transform the input image by swapping the row and column
//! of each source pixel when copying it to the output image.
//! E.g., a pixel at row i and column j of the input image
//! should be copied to row j and column i of the output image.
//! Note that this transformation can only be applied to square
//! images (where the width and height are identical.)
//!
//! @param input_img pointer to the input Image
//! @param output_img pointer to the output Image (in which the
//!                   transformed pixels should be stored)
//!
//! @return 1 if the transformation succeeded, or 0 if the
//!         transformation can't be applied because the image
//!         width and height are not the same
int imgproc_transpose( struct Image *input_img, struct Image *output_img ) {
  //check if square
  if(input_img->width != input_img->height){
    return 0;
  }
  for(int i = 0; i < input_img->height; i++){
    for(int j = 0; j < input_img->width; j++){
      output_img->data[j * input_img->width + i] 
      = input_img->data[i * input_img->width + j]; 
    }
  }

  return 1;
}

//! Transform the input image by copying only those pixels that are
//! within an ellipse centered within the bounds of the image.
//! Pixels not in the ellipse should be left unmodified, which will
//! make them opaque black.
//!
//! Let w represent the width of the image and h represent the
//! height of the image. Let a=floor(w/2) and b=floor(h/2).
//! Consider the pixel at row b and column a is being at the
//! center of the image. When considering whether a specific pixel
//! is in the ellipse, x is the horizontal distance to the center
//! of the image and y is the vertical distance to the center of
//! the image. The pixel at the coordinates described by x and y
//! is in the ellipse if the following inequality is true:
//!
//!   floor( (10000*x*x) / (a*a) ) + floor( (10000*y*y) / (b*b) ) <= 10000
//!
//! @param input_img pointer to the input Image
//! @param output_img pointer to the output Image (in which the
//!                   transformed pixels should be stored)
void imgproc_ellipse( struct Image *input_img, struct Image *output_img ) {
  // TODO: implement
  int width_val = input_img->width;
  int height_val = input_img->height;

  /*if (width_val == 0 || height_val == 0) {
    return;
  }*/

  int a = width_val / 2;   
  int b = height_val / 2;  
  int center_x = width_val / 2;
  int center_y = height_val / 2;

  for (int row = 0; row < height_val; row++) {
    for (int col = 0; col < width_val; col++) {
      int x = col - center_x;
      int y = row - center_y;

      int inequality_left = (10000 * x * x) / (a * a) + (10000 * y * y) / (b * b);

      if (inequality_left <= 10000) {
        output_img->data[row * width_val + col] = input_img->data[row * width_val + col];
      } else {
        output_img->data[row * width_val + col] = make_pixel(0, 0, 0, 255);

      }
    }
  }

}

//! Transform the input image using an "emboss" effect. The pixels
//! of the source image are transformed as follows.
//!
//! The top row and left column of pixels are transformed so that their
//! red, green, and blue color component values are all set to 128,
//! and their alpha values are not modified.
//!
//! For all other pixels, we consider the pixel's color component
//! values r, g, and b, and also the pixel's upper-left neighbor's
//! color component values nr, ng, and nb. In comparing the color
//! component values of the pixel and its upper-left neighbor,
//! we consider the differences (nr-r), (ng-g), and (nb-b).
//! Whichever of these differences has the largest absolute value
//! we refer to as diff. (Note that in the case that more than one
//! difference has the same absolute value, the red difference has
//! priority over green and blue, and the green difference has priority
//! over blue.)
//!
//! From the value diff, compute the value gray as 128 + diff.
//! However, gray should be clamped so that it is in the range
//! 0..255. I.e., if it's negative, it should become 0, and if
//! it is greater than 255, it should become 255.
//!
//! For all pixels not in the top or left row, the pixel's red, green,
//! and blue color component values should be set to gray, and the
//! alpha value should be left unmodified.
//!
//! @param input_img pointer to the input Image
//! @param output_img pointer to the output Image (in which the
//!                   transformed pixels should be stored)
void imgproc_emboss( struct Image *input_img, struct Image *output_img ) {
  int width = input_img->width;
  int height = input_img->height;

  for(int i = 0; i < height; i++) {
    for (int j = 0; j < width; j++) {
      uint32_t input = input_img->data[i * width + j];
      uint8_t a = get_a(input);

      if(i == 0 || j == 0) {
        //output_img->data[i * width + j] = MAKE_PIXEL(128, 128, 128, a);
        output_img->data[i * width + j] = ((uint32_t)128 << 24) | ((uint32_t)128 << 16) | ((uint32_t)128 << 8) | a;
      } else {
        uint32_t neighbor = input_img->data[(i - 1) * width + (j - 1)];
        
        // Extract color components
        int r  = get_r(input);
        int g  = get_g(input);
        int b  = get_b(input);

        int nr = get_r(neighbor);
        int ng = get_g(neighbor);
        int nb = get_b(neighbor);

        // Differences
        int dr = nr - r;
        int dg = ng - g;
        int db = nb - b;
        
        // make sure difference is red first if tied
        int diff = dr;
        if (abs(dg) > abs(diff) || (abs(dg) == abs(diff) && diff != dr)) {
          diff = dg;
        }
        
        if (abs(db) > abs(diff) || (abs(db) == abs(diff) && diff != dr && diff != dg)) {
          diff = db;
        }

        // gray = 128 + diff within bounds
        int gray = 128 + diff;
        if (gray < 0) {
          gray = 0;
        }
        if (gray > 255) {
          gray = 255;
        }

        // Create pixel
        output_img->data[i * width + j] = ((uint32_t)gray << 24) | ((uint32_t)gray << 16) | ((uint32_t)gray << 8) | a;
      }
    }
  }
}
