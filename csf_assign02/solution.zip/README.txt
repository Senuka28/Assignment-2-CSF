TODO: Caroline Jia, Senuka Abeysinghe

TODO: 

Senuka: imgproc_complement, imgproc_ellipse, assembly code for complement function

Caroline: imgproc_transpose, imgproc_emboss, unit tests, assembly code for tranpose function

