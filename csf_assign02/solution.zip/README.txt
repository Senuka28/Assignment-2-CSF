TODO: Caroline Jia, Senuka Abeysinghe

TODO: 

Senuka: imgproc_complement, imgproc_ellipse

Caroline: imgproc_transpose, imgproc_emboss, unit tests

